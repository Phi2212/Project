    <!-- Footer-->
        <script>
            let btn = document.querySelector("#btn");
            let sidebar = document.querySelector(".sidebar");
            
            btn.onclick = function(){
                sidebar.classList.toggle("active");
            }
        </script>
        <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
        <script src="../js/admin.js"></script>
    </body>
</html>