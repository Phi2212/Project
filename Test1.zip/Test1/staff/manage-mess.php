<?php include('otherpart/head.php') ?>








<?php include('otherpart/foot.php') ?>