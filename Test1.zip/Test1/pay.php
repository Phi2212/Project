<?php  
    include('config/constants.php');
    $id_user = $_SESSION['user_id'];
    $insert_cart = "INSERT INTO fod_order"






?>